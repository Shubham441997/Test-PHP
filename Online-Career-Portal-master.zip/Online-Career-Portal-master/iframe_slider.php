<!-- Start Slider Frame Size -->
<iframe src="slider.php" 
	style="	border: none;
			display: block;
			height: 480px;
			margin: 0 auto;
			max-width: 100%;
			overflow: hidden;
			padding: 0;
			width: 1097px;"
			marginheight="0"
			marginwidth="0">
</iframe>
<!-- End Slider Frame Size -->
