<html>

<head>
	<link rel="stylesheet" href="css/master.css" type="text/css" />
	<link rel="stylesheet" href="css/footer_bar.css" type="text/css" />
</head>

<body>
<div align="center" id="footer">
		<div id="footer_menu">		
			<ul>
				<li><a href="contact.us.php">Contact Us</a></li>
				<li><a href="career.us.php">Careers</a></li>
				<li><a href="seeker.joinus.php">Post a CV</a></li>
				<li><a href="search.jobs.php">Search Job</a></li>
				<li><a href="search.job.fairs.php">Job Fair</a></li>
				<li><a>|</a></li>
				<li><a href="seeker.login.php">Seeker Login</a></li>
				<li><a href="employer.login.php">Employer Login</a></li>
			</ul>
		</div>
		
		<div id="footer_image">		
			<ul>
				<li><a><font style="font-size:20px; color: #FFFFFF">Follow Us ::</font></a></li>
				<li><a href="https://www.facebook.com"><img src="images/facebook.ico" /></a></li>
				<li><a href="http://plus.google.com"><img src="images/google_plus.ico" /></a></li>
				<li><a href="http://www.twitter.com"><img src="images/twitter.ico" /></a></li>
				<li><a href="http://www.linkedin.com"><img src="images/linkedin.ico" /></a></li>
			</ul>
		</div><br /><br />
		<font color="#FF0000" style="font-size:12px">&copy;2013 All Rights Reserved. Designed by PARAS GARG.</font>
</div>
</body>
</html>