# Online-Career-Portal
#PHP #SQL #MySQL #AdobeDreamweaver

Online Job Portal was a website in which the recruiter could post new job vacancies for any specialization for the hiring process and job seekers could search and apply for any number of jobs. This project also has the dashboard so that each recruiter and job seeker could see their activities. 
