<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="css/navigation_bar.css" type="text/css"  />
</head>

<body>
	<!-- Start of Navigation Bar -->
	<div id="navi_bar">
		
		<center>

		<!-- Start of Logo Image Div in Navigation Bar -->
		<div id="navi_image">
			<a href="index.php">
				<img src="images/logo.jpg" />
			</a>
		</div id="navi_img">
		<!-- End of Logo Image Div in Navigation Bar-->
		
		<!-- Start of Navi_Shift_Left Div in Navigation Bar -->
		<div id="navi_shift_left">
			<a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="search.jobs.php">Find Job</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="search.job.fairs.php">Job Hub</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="seeker.joinus.php">Post your CV</a>
		</div id="navi_shift_left">
		<!-- Start of Navi_Shift_Left Div in Navigation Bar -->
		
		<!-- Start of Hiring? Div in Navigation Bar -->
		<div id="navi_shift_right">
			<a href="employer.login.php">Hiring?</a>
		</div id="navi_shift_right">
		<!-- End of Hiring? Div in Navigation Bar -->
		
		</center>
	
	</div id="navi_bar">
	<!-- End of Navigation Bar -->
	<br  />
</body>

</html>
